module.exports = {
  require: '@babel/register',
  timeout: 60 * 1000, // 1 minute timeout
};
