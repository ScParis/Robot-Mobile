/**
 * Env configuration for NSIS target
 */
module.exports = { 
  NO_AUTO_UPDATE: true
};

